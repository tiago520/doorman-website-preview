// A single readable product story, presented with two produced music choices.
// Brand artwork stays upright and uniformly scaled. Product captures are examples.
export const duration=48;
export const fps=60;
export const shots=[
 {start:0,duration:4,kind:'opening',text:'AI moves fast. Keep control.'},
 {start:4,duration:4,kind:'reveal',text:'Meet Doorman. The AI gateway.'},
 {start:8,duration:6,kind:'tools',text:'Keep your tools. Bring supported AI traffic through one gateway.'},
 {start:14,duration:6,kind:'routing',text:'Route with intent. The task and your policy guide the model.'},
 {start:20,duration:6,kind:'budgets',text:'Set the limits. Choose budgets and how they are enforced.'},
 {start:26,duration:6,kind:'rules',text:'Define the boundaries. Data rules. Agent permissions.'},
 {start:32,duration:6,kind:'spend',text:'See the spend. Follow recorded costs in one console.'},
 {start:38,duration:4,kind:'ownership',text:'Your tools. Your keys. Your rules.'},
 {start:42,duration:6,kind:'end',text:'Your AI. Under control. doorman.ai'}
];
export const films=[
 {id:'07-studio-groove',title:'Studio groove',duration,poster:2.5,track:'Deep Urban',artist:'Eugenio Mininni',source:'deep-urban-source.mp3',offset:16,shots},
 {id:'08-studio-club',title:'Club mix',duration,poster:16.8,track:'Cat Walk',artist:'Arulo',source:'cat-walk-source.mp3',offset:24,shots}
];
export const palette={ink:'#18201b',paper:'#f7f7f3',yellow:'#ffe600',white:'#ffffff',muted:'#69746c'};
export const clamp=t=>Math.max(0,Math.min(1,t));
const ease=t=>1-Math.pow(1-clamp(t),3);
const smooth=t=>{t=clamp(t);return t*t*(3-2*t);};
const mix=(a,b,t)=>a+(b-a)*t;

export function drawFrame(ctx,A,index,format,time){
 const V=format==='vertical',W=V?1080:1920,H=V?1920:1080,M=V?88:112;
 const active=Math.max(0,shots.findLastIndex(s=>s.start<=time));
 const s=shots[active],u=time-s.start;
 ctx.save();ctx.clearRect(0,0,W,H);ctx.fillStyle='#050705';ctx.fillRect(0,0,W,H);
 ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';
 // Overlapping scene dissolves keep the eye anchored. Text is never cut into words.
 if(active>0&&u<.48){scene(shots[active-1],time,1);scene(s,time,smooth(u/.48));}
 else scene(s,time,1);
 ctx.restore();

 function scene(s,t,opacity){
  ctx.save();ctx.globalAlpha=opacity;
  const u=t-s.start,p=clamp(u/s.duration),enter=ease((u-.08)/.62),move=(1-enter)*26;
  background(s.kind,t,p);
  const white='#f7f7f3',yellow='#ffe600',soft='#b8c0b9';
  function font(size,weight=700){ctx.font=`${size}px Inter${weight}`;ctx.letterSpacing=`${size>60?-size*.044:0}px`;ctx.textBaseline='alphabetic';ctx.textAlign='left';}
  function txt(str,x,y,size,color=white,weight=700,max=W-2*M,align='left'){
   font(size,weight);while(ctx.measureText(str).width>max&&size>15){size-=1;font(size,weight);}ctx.fillStyle=color;ctx.textAlign=align;ctx.fillText(str,x,y);ctx.textAlign='left';
  }
  function line(x,y,x2,y2,color='rgba(255,255,255,.16)',width=1){ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x2,y2);ctx.lineWidth=width;ctx.strokeStyle=color;ctx.stroke();}
  function round(x,y,w,h,r=18,color='#18201b'){ctx.beginPath();ctx.roundRect(x,y,w,h,r);ctx.fillStyle=color;ctx.fill();}
  function wordmark(x,y,w){ctx.drawImage(A.wordmarkWhite,x,y,w,w*48/215.777);}
  function marker(){wordmark(M,V?154:61,V?246:234);}
  function caption(str,y=V?1650:995){txt(str,M,y,V?29:27,soft,400);}
  function heading(lines,sub,opts={}){
   const y=opts.y??(V?390:220),size=opts.size??(V?107:110),gap=size*1.02;
   ctx.save();ctx.globalAlpha*=enter;ctx.translate(0,move);
   lines.forEach((l,i)=>txt(l,M,y+i*gap,size,white,700,opts.width??W-2*M));
   if(sub)txt(sub,M,y+lines.length*gap+27,V?34:33,soft,400,W-2*M);
   ctx.restore();
  }
  function panel(x,y,w,h,draw){
   ctx.save();ctx.shadowColor='rgba(0,0,0,.75)';ctx.shadowBlur=66;ctx.shadowOffsetY=30;
   round(x,y,w,h,20,'#101510');ctx.shadowColor='transparent';
   const edge=ctx.createLinearGradient(x,y,x+w,y+h);edge.addColorStop(0,'rgba(255,255,255,.54)');edge.addColorStop(.35,'rgba(255,255,255,.10)');edge.addColorStop(1,'rgba(255,230,0,.22)');
   ctx.strokeStyle=edge;ctx.lineWidth=1.8;ctx.stroke();
   ctx.beginPath();ctx.roundRect(x+2,y+2,w-4,h-4,18);ctx.clip();draw();ctx.restore();
  }
  function capture(im,crop,x,y,w,h){
   const [sx,sy,sw,sh]=crop,r=w/h,bw=Math.min(sw,sh*r),bh=bw/r;
   const zoom=mix(1.16,1.0,ease(u/1.6)),cw=bw/zoom,ch=bh/zoom;
   const yy=y+mix(25,0,enter)+Math.sin(p*Math.PI)*-7;
   panel(x,yy,w,h,()=>{
    ctx.drawImage(im,sx+(sw-cw)*.5,sy+(sh-ch)*.5,cw,ch,x,yy,w,h);
    const glint=ctx.createLinearGradient(x+w*(p-.4),yy,x+w*(p+.4),yy+h);glint.addColorStop(0,'rgba(255,255,255,0)');glint.addColorStop(.5,'rgba(255,255,255,.025)');glint.addColorStop(1,'rgba(255,255,255,0)');ctx.fillStyle=glint;ctx.fillRect(x,yy,w,h);
   });
   // A soft ground reflection gives the UI a physical place in the studio.
   const floor=ctx.createRadialGradient(x+w*.5,yy+h+34,1,x+w*.5,yy+h+34,w*.45);floor.addColorStop(0,'rgba(224,230,205,.09)');floor.addColorStop(1,'rgba(224,230,205,0)');ctx.fillStyle=floor;ctx.fillRect(x,yy+h+12,w,95);
  }
  function chip(label,x,y,w,h=94){panel(x,y,w,h,()=>{txt(label,x+31,y+h*.61,36,white,500,w-62);});}
  function path(points,phase=0){
   const [x1,y1,x2,y2]=points;
   ctx.beginPath();ctx.moveTo(x1,y1);ctx.bezierCurveTo(mix(x1,x2,.6),y1,mix(x1,x2,.4),y2,x2,y2);ctx.strokeStyle='rgba(235,241,218,.20)';ctx.lineWidth=2;ctx.stroke();
   const q=(u*.24+phase)%1;
   const x=Math.pow(1-q,3)*x1+3*Math.pow(1-q,2)*q*mix(x1,x2,.6)+3*(1-q)*q*q*mix(x1,x2,.4)+q*q*q*x2;
   const y=(Math.pow(1-q,3)+3*Math.pow(1-q,2)*q)*y1+(3*(1-q)*q*q+q*q*q)*y2;
   ctx.beginPath();ctx.arc(x,y,4,0,Math.PI*2);ctx.fillStyle=yellow;ctx.fill();
  }
  if(s.kind==='opening'){
   marker();
   ctx.save();ctx.translate(0,move);ctx.globalAlpha*=enter;
   const y=V?704:431,sz=V?148:163;
   txt('AI moves',M,y,sz);txt('fast.',M,y+sz*1.06,sz);
   txt('Keep control.',M,V?1220:827,V?57:51,yellow,500);
   ctx.restore();
  }else if(s.kind==='reveal'){
   const ww=V?880:1050,x=(W-ww)/2,y=V?764:358;
   ctx.save();ctx.globalAlpha*=enter;ctx.translate(0,move);wordmark(x,y,ww);
   txt('The AI gateway.',W/2,V?1132:733,V?66:61,white,500,W-2*M,'center');
   if(V){txt('For supported tools',W/2,1355,33,soft,400,W-2*M,'center');txt('and traffic.',W/2,1400,33,soft,400,W-2*M,'center');}
   else txt('For supported tools and traffic.',W/2,841,32,soft,400,W-2*M,'center');ctx.restore();
  }else if(s.kind==='tools'){
   marker();heading(V?['Keep your','tools.']:['Keep your tools.'],'One gateway. Your models.');
   if(V){
    ['Claude Code','Codex','Your AI apps'].forEach((l,j)=>chip(l,M,774+j*121,W-2*M,99));
    const cy=1390;path([W/2,1143,W/2,1234],.1);ctx.drawImage(A.app,W/2-133,cy-133,266,266);
    txt('Your providers. Your keys.',W/2,1640,32,soft,400,W-2*M,'center');
   }else{
    ['Claude Code','Codex','Your AI apps'].forEach((l,j)=>{const yy=467+j*133;chip(l,M,yy,462,103);path([M+464,yy+51,883,641],j*.3);});
    ctx.drawImage(A.app,861,503,276,276);path([1138,641,1400,641],.2);
    chip('Your models',1411,527,397,101);chip('Your providers',1411,657,397,101);
    caption('Connect supported clients through Doorman.');
   }
  }else if(s.kind==='routing'){
   marker();heading(V?['Route with','intent.']:['Route with intent.'],V?'The task. The policy. The model.':'The task and your policy guide the model.');
   capture(A.routing,V?[550,340,1220,925]:[540,370,2610,900],M,V?825:410,W-2*M,V?687:541);
   caption('Sample console · example data',V?1590:1007);
  }else if(s.kind==='budgets'){
   marker();heading(V?['Set the','limits.']:['Set the limits.'],V?'Choose budgets and enforcement.':'Choose budgets and how they are enforced.');
   capture(A.budgets,V?[550,375,1220,925]:[540,340,2610,900],M,V?825:410,W-2*M,V?687:541);
   caption('Sample console · example data',V?1590:1007);
  }else if(s.kind==='rules'){
   marker();heading(V?['Define the','boundaries.']:['Define the boundaries.'],'Data rules. Agent permissions.');
   const y=V?854:482,w=V?W-2*M:814,hh=V?245:307;
   function rule(title,body,x,yy,num){
    panel(x,yy,w,hh,()=>{
     txt(num,x+35,yy+62,27,yellow,500);
     txt(title,x+35,yy+(V?133:154),V?62:67,white,600,w-70);
     txt(body,x+35,yy+(V?195:235),V?30:32,soft,400,w-70);
    });
   }
   rule('Data rules','Choose what can be sent.',M,y,'01');
   rule('Agent permissions','Define allowed actions.',V?M:M+w+66,V?y+279:y,'02');
   caption('Controls apply to supported traffic.',V?1558:971);
  }else if(s.kind==='spend'){
   marker();heading(V?['See the','spend.']:['See the spend.'],V?'Follow recorded costs.':'Follow recorded costs in one console.');
   capture(A.spend,V?[550,1160,1220,925]:[550,1170,2530,880],M,V?825:410,W-2*M,V?687:541);
   caption('Sample console · example data',V?1590:1007);
  }else if(s.kind==='ownership'){
   marker();
   const y=V?700:409,sz=V?113:125,gap=V?214:161;
   ['Your tools.','Your keys.','Your rules.'].forEach((l,j)=>{ctx.save();ctx.globalAlpha*=ease((u-j*.13)/.6);txt(l,M,y+j*gap,sz,j===2?yellow:white);ctx.restore();});
  }else if(s.kind==='end'){
   marker();const y=V?719:427,sz=V?135:157;
   ctx.save();ctx.globalAlpha*=enter;ctx.translate(0,move);
   txt('Your AI.',M,y,sz);txt('Under control.',M,y+sz*1.12,V?111:145);
   const by=V?1371:820;line(M,by-58,V?W-M:1066,by-58,'rgba(255,255,255,.25)',1.5);
   txt('doorman.ai',M,by,V?59:55,yellow,600);
   const ax=V?W-M-40:1014,ay=by-22;line(ax-18,ay+18,ax+22,ay-22,yellow,3);line(ax-8,ay-22,ax+22,ay-22,yellow,3);line(ax+22,ay-22,ax+22,ay+8,yellow,3);
   caption('For supported tools and traffic.',V?1630:1004);ctx.restore();
  }
  ctx.restore();
 }

 function background(kind,t,p){
  const im=['reveal','routing','rules','ownership'].includes(kind)?A.fins:A.ribbons;
  const scale=Math.max(W/im.width,H/im.height)*(1.15-.09*smooth(p)+.025*Math.sin(t*.07));
  const iw=im.width*scale,ih=im.height*scale;
  const dx=(W-iw)*(V?.66:.5)+Math.sin(t*.075)*17,dy=(H-ih)/2+Math.cos(t*.09)*12;
  ctx.drawImage(im,dx,dy,iw,ih);
  const shade=ctx.createLinearGradient(0,0,W,H*.14);shade.addColorStop(0,'rgba(3,6,3,.22)');shade.addColorStop(.48,'rgba(3,6,3,.12)');shade.addColorStop(1,'rgba(3,6,3,0)');ctx.fillStyle=shade;ctx.fillRect(0,0,W,H);
  if(V){const shade=ctx.createLinearGradient(0,0,0,H);shade.addColorStop(0,'rgba(3,6,3,.2)');shade.addColorStop(.48,'rgba(3,6,3,.36)');shade.addColorStop(1,'rgba(3,6,3,.15)');ctx.fillStyle=shade;ctx.fillRect(0,0,W,H);}
  // Moving studio light crosses the backdrop, while copy remains fixed and clear.
  const lx=W*(.7+.12*Math.sin(t*.18)),ly=H*(.3+.14*Math.cos(t*.13));
  const light=ctx.createRadialGradient(lx,ly,10,lx,ly,W*.47);light.addColorStop(0,'rgba(231,233,202,.045)');light.addColorStop(1,'rgba(231,233,202,0)');ctx.fillStyle=light;ctx.fillRect(0,0,W,H);
  const edge=ctx.createLinearGradient(0,H*.78,0,H);edge.addColorStop(0,'rgba(2,4,2,0)');edge.addColorStop(1,'rgba(2,4,2,.60)');ctx.fillStyle=edge;ctx.fillRect(0,0,W,H);
 }
}
