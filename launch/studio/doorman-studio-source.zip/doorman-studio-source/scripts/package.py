"""Package finished videos and editable sources separately, excluding standalone music."""
from pathlib import Path
from zipfile import ZipFile,ZIP_STORED,ZIP_DEFLATED
ROOT=Path(__file__).resolve().parents[1]
KIT=ROOT/'doorman-studio-launch-kit.zip'
with ZipFile(KIT,'w') as z:
    files=[*(ROOT/'exports').glob('*.mp4'),ROOT/'exports/doorman-studio.srt',ROOT/'README.md']
    for p in sorted(files):z.write(p,Path('doorman-studio-launch-kit')/p.relative_to(ROOT),compress_type=ZIP_STORED if p.suffix=='.mp4' else ZIP_DEFLATED)
SOURCE=ROOT/'doorman-studio-source.zip'
with ZipFile(SOURCE,'w') as z:
    for p in sorted(ROOT.rglob('*')):
        rel=p.relative_to(ROOT)
        if not p.is_file() or {'.render','audio','exports','previews','posters','node_modules','.venv','__pycache__'}.intersection(rel.parts):continue
        if p.suffix in {'.zip','.pyc'} or p.name=='music-license-observation.txt':continue
        z.write(p,Path('doorman-studio-source')/rel,compress_type=ZIP_STORED if p.suffix in {'.png','.woff2'} else ZIP_DEFLATED)
for p in [KIT,SOURCE]:
    with ZipFile(p) as z:
        assert z.testzip() is None
        assert not any(n.endswith(('.mp3','.m4a','.wav')) for n in z.namelist())
    assert p.stat().st_size<100*1024*1024,'Archive exceeds the Pages repository file limit.'
    print(f'Verified {p.name}: {p.stat().st_size/1024/1024:.1f} MiB',flush=True)
