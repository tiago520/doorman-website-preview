"""720p WebM fallbacks let open-codec browsers play the gallery as well."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess
import imageio_ffmpeg

ROOT=Path(__file__).resolve().parents[1]
def encode(source):
    target=ROOT/'previews'/source.with_suffix('.webm').name
    scale='720:1280' if 'vertical' in source.name else '1280:720'
    subprocess.run([imageio_ffmpeg.get_ffmpeg_exe(),'-y','-hide_banner','-loglevel','error','-i',str(source),'-vf','scale='+scale,'-c:v','libvpx-vp9','-crf','28','-b:v','0','-row-mt','1','-cpu-used','5','-threads','3','-pix_fmt','yuv420p','-c:a','libopus','-b:a','160k',str(target)],check=True)
    print('Preview: '+target.name,flush=True)

if __name__=='__main__':
    (ROOT/'previews').mkdir(exist_ok=True)
    with ThreadPoolExecutor(max_workers=2) as pool:
        list(pool.map(encode,sorted((ROOT/'exports').glob('07-*.mp4'))))
    # Both soundtracks use the identical film. Preserve the picture stream.
    for orientation in ['landscape','vertical']:
        subprocess.run([imageio_ffmpeg.get_ffmpeg_exe(),'-y','-hide_banner','-loglevel','error',
            '-i',str(ROOT/'previews'/f'07-studio-groove-{orientation}.webm'),
            '-i',str(ROOT/'exports'/f'08-studio-club-{orientation}.mp4'),
            '-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','libopus','-b:a','160k','-t','48',
            str(ROOT/'previews'/f'08-studio-club-{orientation}.webm')],check=True)
        print(f'Preview: 08-studio-club-{orientation}.webm',flush=True)
