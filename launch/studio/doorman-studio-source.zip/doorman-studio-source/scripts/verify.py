"""Check every delivered frame and audio stream, plus reading time and brand color."""
from pathlib import Path
import hashlib,json,subprocess
import av,numpy as np,imageio_ffmpeg
from PIL import Image,ImageDraw,ImageOps
ROOT=Path(__file__).resolve().parents[1]
films=json.loads((ROOT/'films.json').read_text())
results=[]
for f in films:
    assert min(s['duration'] for s in f['shots'])>=4
    for orientation,dimensions in [('landscape',(1920,1080)),('vertical',(1080,1920))]:
        path=ROOT/'exports'/f"{f['id']}-{orientation}.mp4"
        with av.open(path) as c:
            v=c.streams.video[0];a=c.streams.audio[0]
            assert (v.width,v.height)==dimensions and float(v.average_rate)==60
            assert v.codec_context.name=='h264' and v.format.name=='yuv420p'
            assert a.codec_context.name=='aac' and a.sample_rate==48000 and a.channels==2
            assert abs(float(v.duration*v.time_base)-48)<.03
            samples={round((s['start']+s['duration']*.6)*60):i for i,s in enumerate(f['shots'])}
            count=0;stills=[];yellow=None
            for frame in c.decode(video=0):
                if count in samples:
                    im=frame.to_image();number=samples[count]
                    assert np.asarray(im.resize((96,96))).std()>7
                    if number==2:
                        yellow=im.getpixel((885,533) if orientation=='landscape' else (429,1300))
                    stills.append(im)
                count+=1
            assert count==2880
            assert yellow is not None and all(abs(x-y)<6 for x,y in zip(yellow,(255,230,0))),(path,yellow)
        energy=0.;samples_count=0;peak=0.
        with av.open(path) as c:
            for frame in c.decode(audio=0):
                data=frame.to_ndarray().astype(np.float32)
                energy+=float(np.sum(data**2));samples_count+=data.size;peak=max(peak,float(np.max(np.abs(data))))
        rms=float(np.sqrt(energy/samples_count));assert rms>.05 and peak<1.0
        raw=path.read_bytes();assert 0<raw.find(b'moov')<raw.find(b'mdat')
        log=subprocess.run([imageio_ffmpeg.get_ffmpeg_exe(),'-hide_banner','-i',str(path),'-af','loudnorm=I=-14:TP=-1:LRA=9:print_format=json','-f','null','-'],capture_output=True,text=True,check=True).stderr
        loudness=json.loads(log[log.rindex('{'):log.rindex('}')+1])
        assert -15.1<float(loudness['input_i'])<-13 and float(loudness['input_tp'])<-.5
        results.append({'file':path.name,'dimensions':dimensions,'duration':48,'fps':60,'frames':count,'video':'H.264 High / Rec.709','audio':'AAC / stereo / 48 kHz','audio_rms':rms,'audio_peak':peak,'lufs':float(loudness['input_i']),'true_peak_dbtp':float(loudness['input_tp']),'brand_yellow_rgb':yellow,'full_decode':True,'fast_start':True,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
        if f==films[0]:
            cols=3 if orientation=='landscape' else 5;cw,ch=(480,292) if orientation=='landscape' else (230,426)
            sheet=Image.new('RGB',(cols*cw,((len(stills)+cols-1)//cols)*ch),(16,20,17));d=ImageDraw.Draw(sheet)
            for i,im in enumerate(stills):
                thumb=ImageOps.contain(im,(cw-10,ch-28));x=i%cols*cw+(cw-thumb.width)//2;y=i//cols*ch+22
                sheet.paste(thumb,(x,y));d.text((x,y-17),f"{f['shots'][i]['start']:02d}s",fill='white')
            sheet.save(ROOT/'posters'/f'storyboard-{orientation}.jpg',quality=93)
        print(f'Verified {path.name}: 2,880 frames, 48 seconds, stereo music, readable holds.',flush=True)
(ROOT/'exports'/'verification.json').write_text(json.dumps({'exports':results,'reading_time':{'minimum_scene_seconds':4,'minimum_settled_headline_seconds':3.3,'maximum_scene_seconds':6,'story_scenes':9},'verification_scope':'Media decoding, audio levels, brand-color sample and delivery timing. Audience response is not measured.'},indent=2)+'\n')
