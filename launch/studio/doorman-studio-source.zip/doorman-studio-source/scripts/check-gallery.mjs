import {createRequire} from 'node:module';
import {writeFile} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const require=createRequire(import.meta.url),{chromium}=require(process.env.PLAYWRIGHT_MODULE||'playwright');
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const base=process.env.PREVIEW_URL||'http://127.0.0.1:48632/';
const browser=await chromium.launch({headless:true}),checks=[],errors=[];
try{
 for(const viewport of [{width:1440,height:1100},{width:390,height:844}]){
  const page=await browser.newPage({viewport,reducedMotion:'reduce'});
  page.on('pageerror',e=>errors.push(e.message));page.on('response',r=>{if(r.status()>=400)errors.push(`${r.status()} ${r.url()}`);});
  await page.goto(base,{waitUntil:'networkidle'});await page.evaluate(()=>document.fonts.ready);
  if(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth))throw Error('Horizontal overflow');
  if(!await page.evaluate(()=>document.fonts.check('600 44px Inter')))throw Error('Inter not loaded');
  if(!await page.locator('#player').evaluate(v=>v.paused))throw Error('Video autoplayed');
  await page.screenshot({path:path.join(root,'posters',`gallery-${viewport.width}.png`),fullPage:true});
  await page.locator('#play-sound').click();
  await page.waitForFunction(()=>{const v=document.querySelector('#player');return v.currentTime>.3&&!v.paused;});
  if(await page.locator('#player').evaluate(v=>v.muted))throw Error('Play with sound remained muted');
  for(let track=0;track<2;track++)for(const format of ['landscape','vertical']){
   await page.locator(`[data-track="${track}"]`).click();await page.locator(`[data-format="${format}"]`).click();
   await page.waitForFunction(()=>{const v=document.querySelector('#player');return v.readyState>=2&&!v.paused&&!v.seeking;});
   const media=await page.locator('#player').evaluate(v=>({width:v.videoWidth,height:v.videoHeight,duration:v.duration,src:v.currentSrc,time:v.currentTime,muted:v.muted,error:v.error?.message||null}));
   const webm=media.src.includes('.webm'),expected=format==='landscape'?(webm?[1280,720]:[1920,1080]):(webm?[720,1280]:[1080,1920]);
   if(media.width!==expected[0]||media.height!==expected[1]||Math.abs(media.duration-48)>.1||media.error||media.muted)throw Error(JSON.stringify(media));
   const expectedName=`${track===0?'07-studio-groove':'08-studio-club'}-${format}`;
   if(!media.src.includes(expectedName))throw Error('Wrong selected soundtrack or format');
   const link=await page.locator('#video-download').getAttribute('href');if(link!==`exports/${expectedName}.mp4`)throw Error('Wrong MP4 download');
   checks.push({viewport:viewport.width,track,format,...media,playback:true,download:link});
  }
  await page.locator('#player').evaluate(v=>{v.currentTime=18;});
  await page.waitForFunction(()=>document.querySelector('#player').currentTime>=18);
  await page.locator('[data-track="0"]').click();await page.waitForFunction(()=>{const v=document.querySelector('#player');return v.readyState>=2&&!v.paused&&!v.seeking&&v.currentTime>=18;});
  const preserved=await page.locator('#player').evaluate(v=>v.currentTime);if(preserved>21)throw Error('Soundtrack switch did not preserve position');
  await page.locator('#player').evaluate(v=>v.pause());
  await page.locator('[data-format="landscape"]').click();
  await page.waitForFunction(()=>document.querySelector('#player').readyState>=2);
  const links=await page.locator('a[download]').evaluateAll(as=>as.map(a=>a.href));
  for(const href of [...new Set(links)])if(!(await page.request.head(href)).ok())throw Error(`Missing download ${href}`);
  await page.locator('[data-format="vertical"]').focus();await page.keyboard.press('Enter');
  if(await page.locator('[data-format="vertical"]').getAttribute('aria-pressed')!=='true')throw Error('Keyboard selection failed');
  await page.close();
 }
 if(errors.length)throw Error(errors.join('\n'));
 await writeFile(path.join(root,'exports','gallery-verification.json'),JSON.stringify({checks,errors,soundtrack_position_preserved:true,explicit_play_with_sound:true,autoplay:false},null,2)+'\n');
 console.log('Gallery passed: desktop and mobile, eight media combinations, sound enabled, soundtrack switching, downloads and keyboard controls.');
}finally{await browser.close();}
