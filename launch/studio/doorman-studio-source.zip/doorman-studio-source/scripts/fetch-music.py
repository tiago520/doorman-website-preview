"""Download the two specifically selected tracks from their provider for sync editing."""
from pathlib import Path
from urllib.request import Request,urlopen
import json
ROOT=Path(__file__).resolve().parents[1]
(ROOT/'audio').mkdir(exist_ok=True)
(ROOT/'.render').mkdir(exist_ok=True)
names={'Deep Urban':'deep-urban-source.mp3','Cat Walk':'cat-walk-source.mp3'}
for track in json.loads((ROOT/'references/music-sources.json').read_text()):
    target=ROOT/'audio'/names[track['name']]
    if not target.exists():
        with urlopen(Request(track['url'],headers={'User-Agent':'Mozilla/5.0'}),timeout=60) as response:
            target.write_bytes(response.read())
    print(f"Ready for video sync: {track['name']} by {track['byArtist']}")
print('Use under the Mixkit Stock Music Free License: https://mixkit.co/license/#musicFree')
