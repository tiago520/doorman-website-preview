"""Create private sync edits of the licensed tracks, solely for the finished videos."""
from pathlib import Path
import hashlib,json,subprocess
import imageio_ffmpeg

ROOT=Path(__file__).resolve().parents[1]
FF=imageio_ffmpeg.get_ffmpeg_exe()
def ff(args):
    return subprocess.run([FF,'-hide_banner','-y',*args],capture_output=True,text=True,check=True).stderr

for f in json.loads((ROOT/'films.json').read_text()):
    source=ROOT/'audio'/f['source']
    edit=ROOT/'.render'/f"{f['id']}.wav"
    # Standard sync editing only: excerpt, short edge fades, loudness adjustment.
    ff(['-ss',str(f['offset']),'-i',str(source),'-t',str(f['duration']),'-af',
        'afade=t=in:st=0:d=0.08,afade=t=out:st=46.3:d=1.7','-ar','48000','-ac','2',str(edit)])
    log=ff(['-i',str(edit),'-af','loudnorm=I=-14:TP=-1:LRA=9:print_format=json','-f','null','-'])
    m=json.loads(log[log.rindex('{'):log.rindex('}')+1])
    filt=f"loudnorm=I=-14:TP=-1:LRA=9:measured_I={m['input_i']}:measured_TP={m['input_tp']}:measured_LRA={m['input_lra']}:measured_thresh={m['input_thresh']}:offset={m['target_offset']}:linear=true:print_format=json"
    target=ROOT/'.render'/f"{f['id']}.m4a"
    log=ff(['-i',str(edit),'-af',filt,'-ar','48000','-c:a','aac','-b:a','256k','-movflags','+faststart',str(target)])
    final=json.loads(log[log.rindex('{'):log.rindex('}')+1])
    (ROOT/'references'/f"{f['id']}-audio.json").write_text(json.dumps({
      'track':f['track'],'artist':f['artist'],'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
      'source_start':f['offset'],'duration':f['duration'],'license':'Mixkit Stock Music Free License',
      'source_page':'https://mixkit.co/free-stock-music/house/','license_url':'https://mixkit.co/license/#musicFree',
      'changes':'48-second audiovisual sync excerpt, edge fades and loudness normalization. No new musical arrangement.',
      'measurement':final,'delivery':'Music is included in finished video exports; standalone tracks are not distributed.'
    },indent=2)+'\n')
    print(f"Prepared {f['track']} by {f['artist']}: {final['output_i']} LUFS, {final['output_tp']} dBTP",flush=True)
