import {createCanvas,GlobalFonts,loadImage} from '@napi-rs/canvas';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {spawn,execFileSync} from 'node:child_process';
import {once} from 'node:events';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {drawFrame,films,shots,duration,fps} from '../film.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const argv=process.argv.slice(2),get=(name,fallback)=>argv.includes(name)?argv[argv.indexOf(name)+1]:fallback;
const ffmpeg=process.env.FFMPEG||execFileSync(process.env.PYTHON||'python3',['-c','import imageio_ffmpeg;print(imageio_ffmpeg.get_ffmpeg_exe())'],{encoding:'utf8'}).trim();
const formats=get('--format','all')==='all'?['landscape','vertical']:[get('--format','landscape')];
for(const dir of ['exports','posters','.render'])await mkdir(path.join(root,dir),{recursive:true});
for(const weight of [400,500,600,700])if(!GlobalFonts.registerFromPath(path.join(root,`assets/Inter-${weight}.ttf`),`Inter${weight}`))throw Error(`Inter ${weight} unavailable`);
const files={wordmarkWhite:'switch-wordmark-white.svg',symbol:'switch-icon.svg',app:'switch-app.svg',ribbons:'ribbons.png',fins:'fins.png',routing:'routing.png',budgets:'budgets.png',spend:'spend.png'};
const assets=Object.fromEntries(await Promise.all(Object.entries(files).map(async([key,value])=>[key,await loadImage(await readFile(path.join(root,'assets',value)))])));
function ff(args){return new Promise((resolve,reject)=>{const p=spawn(ffmpeg,args,{stdio:['ignore','ignore','pipe']});let log='';p.stderr.on('data',d=>log+=d);p.on('error',reject);p.on('close',code=>code?reject(Error(log)):resolve());});}
await writeFile(path.join(root,'films.json'),JSON.stringify(films,null,2)+'\n');
for(const format of formats){
 const width=format==='vertical'?1080:1920,height=format==='vertical'?1920:1080;
 const canvas=createCanvas(width,height),ctx=canvas.getContext('2d');
 for(const [i,f] of films.entries()){
  drawFrame(ctx,assets,i,format,f.poster);
  await writeFile(path.join(root,'posters',`${f.id}-${format}.jpg`),await canvas.encode('jpeg',94));
 }
 for(let i=0;i<shots.length;i++){
  drawFrame(ctx,assets,0,format,shots[i].start+shots[i].duration*.55);
  await writeFile(path.join(root,'.render',`${format}-${i}.jpg`),await canvas.encode('jpeg',93));
 }
 if(argv.includes('--posters'))continue;
 const picture=path.join(root,'.render',`picture-${format}.mp4`);
 const proc=spawn(ffmpeg,['-y','-hide_banner','-loglevel','error','-f','rawvideo','-pixel_format','rgba','-video_size',`${width}x${height}`,'-framerate',String(fps),'-i','pipe:0','-vf','scale=iw:ih:in_range=pc:out_range=tv:out_color_matrix=bt709,format=yuv420p','-c:v','libx264','-preset','fast','-crf','17','-threads','4','-profile:v','high','-level','4.2','-g','120','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709','-an','-movflags','+faststart',picture],{stdio:['pipe','ignore','pipe']});
 let error=null,log='';proc.stderr.on('data',d=>log+=d);proc.stdin.on('error',e=>error=e);
 const completed=new Promise((resolve,reject)=>{proc.on('error',reject);proc.on('close',code=>code?reject(Error(log)):resolve());});completed.catch(()=>{});
 const start=Date.now();
 for(let frame=0;frame<duration*fps;frame++){
  if(error)throw error;drawFrame(ctx,assets,0,format,frame/fps);
  if(!proc.stdin.write(canvas.data()))await once(proc.stdin,'drain');
  if(frame%600===0)console.log(`${format}: ${Math.round(frame/(duration*fps)*100)}%, ${Math.round((Date.now()-start)/1000)}s`);
 }
 proc.stdin.end();await completed;
 for(const f of films){
  const output=path.join(root,'exports',`${f.id}-${format}.mp4`);
  await ff(['-y','-hide_banner','-loglevel','error','-i',picture,'-i',path.join(root,'.render',`${f.id}.m4a`),'-map','0:v:0','-map','1:a:0','-c','copy','-t',String(duration),'-movflags','+faststart','-metadata',`title=Doorman — ${f.title}`,'-metadata','artist=Doorman','-metadata',`comment=Music: ${f.track} by ${f.artist}, Mixkit Stock Music Free License. Console imagery uses example data.`,output]);
  console.log(`Exported ${path.basename(output)}`);
 }
}
const stamp=t=>{const n=Math.round(t*1000);return `00:${String(Math.floor(n/60000)).padStart(2,'0')}:${String(Math.floor(n/1000)%60).padStart(2,'0')},${String(n%1000).padStart(3,'0')}`;};
await writeFile(path.join(root,'exports','doorman-studio.srt'),shots.map((s,i)=>`${i+1}\n${stamp(s.start)} --> ${stamp(s.start+s.duration-.03)}\n${s.text}\n`).join('\n'));
